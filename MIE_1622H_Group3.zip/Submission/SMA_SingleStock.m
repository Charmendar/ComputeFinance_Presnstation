clear all;
close all;

%sinmple moving average
%Reference: http://www.investopedia.com/terms/s/sma.asp

%% Initualize Variable
%define moving intervel
Interval_Short=10;
Interval_Long=30;
%% Import intual data

%IBM
IBM_2016=xlsread('IBM_2016.csv',1,'G:G');
IBM_2016=fliplr(IBM_2016);%reverse order start from day one

Day_count=numel(IBM_2016);
%% SMA
for day_index=1:Day_count
    if day_index<=Interval_Short
    SMA_IBM_S(day_index)=IBM_2016(day_index);
    else
    SMA_IBM_S(day_index)=sum(IBM_2016(day_index-Interval_Short:day_index-1))/Interval_Short;
    end
end


%% SMA
%Short term SMA
SMA_IBM_S=zeros(Day_count,1);
%Long term
SMA_IBM_L=zeros(Day_count,1);

for day_index=1:Day_count
    if day_index<=Interval_Short
    SMA_IBM_S(day_index)=IBM_2016(day_index);
    else
    SMA_IBM_S(day_index)=sum(IBM_2016(day_index-Interval_Short:day_index-1))/Interval_Short;
    end
end

%long term SMA
for day_index=1:Day_count
    if day_index<=Interval_Long
    SMA_IBM_L(day_index)=IBM_2016(day_index);
    else
    SMA_IBM_L(day_index)=sum(IBM_2016(day_index-Interval_Long:day_index-1))/Interval_Long;
    end
end

%% Plot

%IBM
figure
plot(SMA_IBM_S)
hold on
plot(SMA_IBM_L)
hold on
plot(IBM_2016)
hold off
legend('show','Short-term SMA','Long-term SMA','Real Price')
xlabel('Days')
ylabel('Price(dollars)')
title('IBM Year 2016')